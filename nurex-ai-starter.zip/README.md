# Nurex AI

This is the initial version of the Nurex AI landing page.